@extends('layouts.admin')

@section('body')
<div id="page-wrapper">
	<h1>Index page admin</h1>
</div>

@endsection