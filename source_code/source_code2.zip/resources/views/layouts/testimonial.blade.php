<section id="testimonials">

  <div class="testim-ovl"></div>
  <div class="testimonials-wrapper">

   <ul class="testimonials-line">

     <li class="customer">

       <div class="testimonial-bubble">
         <p>Thế giới thật rộng lớn khi tôi phát hiện ra Jobee</p>
       </div>

       <div class="cus-profile">
        <span class="cus-image"><img src="assets/img/te1.jpg"></span>
        <span class="cus-name">
         Elon Musk
         <span class="cus-title">Director SpaceX, Tesla & Paypal</span>
       </span>  
     </div>

   </li>

   <li class="customer">

     <div class="testimonial-bubble">
       <p>Website thật tuyệt vời, tôi đã tuyển được rất nhiều nhân viên từ Jobee</p>
     </div>

     <div class="cus-profile">
      <span class="cus-image"><img src="assets/img/te2.jpg"></span>
      <span class="cus-name">
       Thành Huỳnh
       <span class="cus-title">Giám đốc Ecogreen</span>
     </span>   
   </div>

 </li>

 <li class="customer">

   <div class="testimonial-bubble">
     <p>Trên cả tuyệt vời, mong Jobee sẽ ngày càng phát triển hơn</p>
   </div>

   <div class="cus-profile">
    <span class="cus-image"><img src="assets/img/te3.jpg"></span>
    <span class="cus-name">
     Phạm Nhật Vượng
     <span class="cus-title">Giám đốc Vingroup</span>
   </span>  
 </div>

</li>

<li class="customer">

 <div class="testimonial-bubble">
   <p>Nguồn nhân lực từ nhà trường được đào tạo rất tốt</p>
 </div>

 <div class="cus-profile">
  <span class="cus-image"><img src="assets/img/te1.jpg"></span>
  <span class="cus-name">
   Đinh La Thăng
   <span class="cus-title">Cựu giám đốc PVN</span>
 </span>  

</li>

<span id="prev"></span>
<span id="next"></span>   

</ul><!-- .testimonials-line -->
</div><!-- .testimonials-wrapper -->
</section><!-- .testimonials -->  