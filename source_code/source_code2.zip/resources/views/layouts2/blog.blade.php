<div class="container">
     <header class="section-header">
      <h3>Tin tức</h3>
    </header>

    <!-- blog -->
    <div class="col-md-4">
      <div class="blog">
        <div class="blog-img">
          <img class="img-responsive" src="assets/img/how-it-works.png" alt="">
        </div>
        <div class="blog-content">
          <ul class="blog-meta">
            <li><i class="fa fa-user"></i>Thanh Huynh</li>
            <li><i class="fa fa-clock-o"></i>18/12/2017</li>
            <li><i class="fa fa-comments"></i>57</li>
          </ul>
          <h3>20 IT Blogger Việt bạn không nên bỏ qua</h3>
          <p>30% Developer đọc blog để tìm câu trả lời khi ăn “bí” – Đó là kết quả mà ITviec đã khảo sát được. Do đó, ITviec đã tổng hợp và cập nhật 20 IT blogger Việt Nam “chất” nhất để giúp bạn</p>
          <a href="blog-single.html">Xem thêm</a>
        </div>
      </div>
    </div>
    <!-- /blog -->

    <!-- blog -->
    <div class="col-md-4">
      <div class="blog">
        <div class="blog-img">
          <img class="img-responsive" src="assets/img/how-it-works.png" alt="">
        </div>
        <div class="blog-content">
          <ul class="blog-meta">
            <li><i class="fa fa-user"></i>Thanh Huynh</li>
            <li><i class="fa fa-clock-o"></i>18/12/2017</li>
            <li><i class="fa fa-comments"></i>57</li>
          </ul>
          <h3>20 IT Blogger Việt bạn không nên bỏ qua</h3>
          <p>30% Developer đọc blog để tìm câu trả lời khi ăn “bí” – Đó là kết quả mà ITviec đã khảo sát được. Do đó, ITviec đã tổng hợp và cập nhật 20 IT blogger Việt Nam “chất” nhất để giúp bạn</p>
          <a href="blog-single.html">Xem thêm</a>
        </div>
      </div>
    </div>
    <!-- /blog -->

    <!-- blog -->
    <div class="col-md-4">
      <div class="blog">
        <div class="blog-img">
          <img class="img-responsive" src="assets/img/how-it-works.png" alt="">
        </div>
        <div class="blog-content">
          <ul class="blog-meta">
            <li><i class="fa fa-user"></i>Thanh Huynh</li>
            <li><i class="fa fa-clock-o"></i>18/12/2017</li>
            <li><i class="fa fa-comments"></i>57</li>
          </ul>
          <h3>20 IT Blogger Việt bạn không nên bỏ qua</h3>
          <p>30% Developer đọc blog để tìm câu trả lời khi ăn “bí” – Đó là kết quả mà ITviec đã khảo sát được. Do đó, ITviec đã tổng hợp và cập nhật 20 IT blogger Việt Nam “chất” nhất để giúp bạn</p>
          <a href="blog-single.html">Xem thêm</a>
        </div>
      </div>
    </div>