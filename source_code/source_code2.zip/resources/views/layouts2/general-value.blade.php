<div class="container">

      <div class="row">
        <div class="counter col-md-3 col-sm-6">
          <p><span data-from="0" data-to="6890"></span>+</p>
          <h6>Việc làm</h6>
        </div>

        <div class="counter col-md-3 col-sm-6">
          <p><span data-from="0" data-to="1200"></span>+</p>
          <h6>Ứng viên</h6>
        </div>

        <div class="counter col-md-3 col-sm-6">
          <p><span data-from="0" data-to="36800"></span>+</p>
          <h6>Hồ sơ</h6>
        </div>

        <div class="counter col-md-3 col-sm-6">
          <p><span data-from="0" data-to="15400"></span>+</p>
          <h6>Công ty</h6>
        </div>
      </div>

    </div>