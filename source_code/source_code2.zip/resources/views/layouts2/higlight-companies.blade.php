<div class="container">
    <header class="section-header">
      <h2>Nhà tuyển dụng</h2>
    </header>

    <div class="category-grid">
      <a href="job-list-1.html">
       <img src="assets/img/fpt.jpg" alt="">
       <h6>FPT</h6>
       <span>Hà Nội</span>
     </a>

     <a href="job-list-2.html">
       <img src="assets/img/globalcybersoft.jpg" alt="">
       <h6>Global Cybersoft</h6>
       <span>Hồ Chí Minh</span>
     </a>

     <a href="job-list-3.html">
      <img src="assets/img/logo-google.png" alt="">
      <h6>Facebook</h6>
      <span>Đà Nẵng</span>
    </a>

    <a href="job-list-1.html">
      <img src="assets/img/csc.jpg" alt="">
      <h6>CSC</h6>
      <span>Bình Dương</span>
    </a>

    <a href="job-list-2.html">
      <img src="assets/img/capgemini.jpeg" alt="">
      <h6>Capgemini</h6>
      <span>Đồng Nai</span>
    </a>

    <a href="job-list-3.html">
      <img src="assets/img/kms.png" alt="">
      <h6>KMS</h6>
      <span>Hồ Chí Minh</span>
    </a> 

    <a href="job-list-2.html">
      <img src="assets/img/capgemini.jpeg" alt="">
      <h6>Capgemini</h6>
      <span>Hà Nội</span>
    </a>

    <a href="job-list-2.html">
      <img src="assets/img/logo-google.png" alt="">
      <h6>Capgemini</h6>
      <span>Đà Nẵng</span>
    </a>

  </div>
</div>