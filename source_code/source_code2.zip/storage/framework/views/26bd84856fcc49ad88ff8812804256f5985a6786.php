<!DOCTYPE html>
<html lang="en">
<head>
 <title><?php echo e($title); ?></title>

 <?php echo $__env->yieldContent('meta-data'); ?>
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
 <meta name="keywords" content="">
 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


 <!-- Styles -->
 <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/css/thejobs.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('assets/css/alpha.css')); ?>" rel="stylesheet">

 <!-- Fonts -->
 <link href='http://fonts.googleapis.com/css?family=Oswald:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>

 <!-- Favicons -->
 <link rel="apple-touch-icon" href="<?php echo e(asset('/apple-touch-icon.png')); ?>">
 <link rel="icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?> ">
  
 <script async src="https://www.googletagmanager.com/gtag/js?id=UA-116938224-1"></script>

 <script>  
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){ (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o), m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m) })(window,document,'script','//www.google-analytics.com/analytics.js','ga'); 
  ga('create', 'UA-116938224-1', 'auto'); 
  ga('require', 'linkid', 'linkid.js');
  ga('require', 'displayfeatures'); 
  ga('send', 'pageview');  
</script>
  <?php echo $__env->yieldContent('stylesheet'); ?>


</head>


<body class="nav-on-header smart-nav">
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=415131908928137&autoLogAppEvents=1';
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>
  <!-- Navigation bar -->
  <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END Navigation bar -->

  <?php if($isDisplaySearchHeader): ?>
  <?php echo $__env->make('layouts.search-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php else: ?>

  <?php echo $__env->yieldContent('page-header'); ?>
  
  <?php endif; ?>


  <!-- Main container -->


  <?php echo $__env->yieldContent('content'); ?>


  <!-- END Main container -->


  <!-- Site footer -->
  <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



  <!-- Scripts -->
  <script type="text/javascript" src="<?php echo e(asset('assets/js/app.min.js')); ?> "></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/thejobs.js')); ?> "></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/custom.js')); ?> "></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/alpha.js')); ?> "></script>

  <script type="text/javascript">

    $('#testimonials').alpha({
      layout: 'alt',
      delay : 5300
    });

  </script>

  <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
