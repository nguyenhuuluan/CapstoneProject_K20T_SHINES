<?php $__env->startSection('recentjobs'); ?>
<section>
  <div class="container">
    <header class="section-header">
      <h2>Việc làm mới nhất</h2>
    </header>

    <div class="row item-blocks-connected">
      <?php $__currentLoopData = $recruitments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Job item -->
      <div class="col-xs-12">
        <a class="item-block" href="<?php echo e(route('detailrecruitment', $recruitment->slug )); ?>">
          <header>
            <img src="<?php echo e(asset($recruitment->company->logo)); ?>" alt="">
            <div class="hgroup">
              <h4><?php echo e($recruitment->title); ?></h4>
              <h5><?php echo e($recruitment->company->name); ?></h5>
            </div>
            <div class="header-meta">
              <span class="location"><?php echo e($recruitment->company->address->district->city->name); ?></span>
              <?php $__currentLoopData = $recruitment->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($category->name =='FULL-TIME'): ?>
              <span class="label label-success"><?php echo e($category->name); ?></span>
              <?php else: ?>
              <span class="label label-danger"><?php echo e($category->name); ?></span>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
          </header>
        </a>
      </div>
      <!-- END Job item -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br><br>
    <p class="text-center"><a class="btn btn-info" href="<?php echo e(route('lst.recruitment')); ?>">Xem thêm</a></p>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('topcompany'); ?>
<!-- How it works -->
<section>
 <div class="container">
  <header class="section-header">
    <h2>Nhà tuyển dụng</h2>
  </header>

  <div class="category-grid">
  
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <a href="<?php echo e(route('company.details', $company->slug )); ?>">
     <img src="<?php echo e(asset($company->logo)); ?>" alt="" style="height: 200px">
     <h6><?php echo $company->name; ?></h6>
     <span><?php echo $company->address->district->city->name; ?></span>
   </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</section>
<!-- END How it works -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>