<?php $__env->startSection('styles'); ?>
<!-- DataTables CSS -->
<link href="<?php echo e(asset('assets/vendors/datatables-plugins/dataTables.bootstrap.css')); ?> " rel="stylesheet">
<!-- DataTables Responsive CSS -->
<link href="<?php echo e(asset('assets/vendors/datatables-responsive/dataTables.responsive.css')); ?> " rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<!-- Main container -->
<main>
   <section>
      <div class="container">
         <div class="row"> 
            <?php if(Session::has('comment_message')): ?>
            <div class="container">
               <ul class="alert alert-success">
                  <?php echo e(session('comment_message')); ?>

               </ul>
            </div>   
            <?php endif; ?>
            <div class="col-lg-12">
               <div class="panel-body">
                  <div class="table-responsive">
                     <table width="100%" id="dataTables-example" class="table table-striped table-hover table-bordered-company">
                        <thead>
                           <tr>
                              <th>ID</th>
                              <th>Tiêu đề việc làm</th>
                              <th>Lĩnh Vực</th>
                              <th>Lương</th>
                              <th>Ngày đăng</th>
                              <th>Ngày hết hạn</th>
                              <th>Lượt xem</th>
                              <th>Trạng thái</th>
                              <th>Thao tác</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $recruitments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                              <td><?php echo e($recruitment->id); ?></td>
                              <td><a href="<?php echo e($recruitment->path()); ?>" target="_blank"><?php echo e($recruitment->title); ?></a></td>
                              <td><?php echo e($recruitment->salary); ?></td>
                              <td>
                                 <?php foreach ($recruitment->tags as $tag){
                                    echo '<span class="label label-default">'.$tag->name.'</span>';
                                 }                                   
                                 ?>
                                 
                              </td>
                              <td><?php echo e($recruitment->created_at); ?></td>
                              <td><?php echo e($recruitment->expire_date); ?></td>
                              <td><center><?php echo e($recruitment->number_of_view); ?></center></td>
                              <td>
                                 <?php if($recruitment->status->id == '1'): ?>
                                 <span class="label label-success">Đã duyệt</span>
                                 <?php elseif($recruitment->status->id == '8'): ?>
                                 <span class="label label-warning">Đang chờ</span>
                                 <?php elseif($recruitment->status->id == '2'): ?>
                                 <span class="label label-danger">Tạm dừng</span>
                                 <?php endif; ?>
                              </td>
                              <td>
                                 <center>
                                    <a href="mn-job-add-company.html" target="_blank"><abbr title="Sửa"><i class="fa fa-pencil" aria-hidden="true"></i></abbr></a>
                                    <a href="#"><abbr title="Xóa"><i class="fa fa-trash" aria-hidden="true"></i></abbr></a>
                                 </center>
                              </td>
                           </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
         <a class="btn btn-success-detail" href="<?php echo e(route('recruitments.create')); ?>" target="_blank">Thêm tin tuyển dụng</a>
      </div>
   </section>
</main>
<!-- END Main container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<!-- DataTables JavaScript -->
<script src="<?php echo e(asset('assets/vendors/datatables/js/jquery.dataTables.min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/vendors/datatables-plugins/dataTables.bootstrap.min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/vendors/datatables-responsive/dataTables.responsive.js')); ?> "></script>
<script>
   $(document).ready(function() {
    $('#dataTables-example').DataTable({
     responsive: true
  });
 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.representative', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>