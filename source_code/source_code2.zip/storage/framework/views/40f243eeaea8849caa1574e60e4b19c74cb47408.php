<?php $__env->startSection('page-header'); ?>


<header class="page-header bg-img size-lg" style="background-image: url(<?php echo e(asset('assets/img/bg-banner2.jpg')); ?> )">
    <div class="container">
      <div class="header-detail">
        <img class="logo" height="60" src=<?php echo asset($recruitment->company->logo); ?> alt="">
        <div class="hgroup">
          <h1><?php echo $recruitment->title; ?></h1>
        </div>
        <time datetime=""><?php echo $recruitment->created_at->diffForhumans(); ?></time>
        <ul class="details cols-3"  style="text-align: center">
          <li>
            <h3><a href="#"><?php echo $recruitment->company->name; ?></a></h3>
          </li>
          <li>
            <i class="fa fa-money"></i>
					<span class="salary"><?php echo $recruitment->salary; ?></span>
          </li>
          <li>
					<?php $__currentLoopData = $recruitment->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($category->name == 'FULL-TIME' ): ?>
					<span class="label label-success"><?php echo $category->name; ?></span>
					<?php else: ?>
					<span class="label label-danger"><?php echo $category->name; ?></span>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </li>
        </ul>
        
        <div class="button-group">
          <ul class="social-icons">
            <li class="title">Chia sẻ</li>
            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
          </ul>

          <div class="action-buttons">
            <a class="btn btn-success-detail" href="job-apply.html">Ứng tuyển ngay</a>
          </div>
        </div>


      </div>
    </div>
  </header>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-container'); ?>


<main class="container blog-page">

	<div class="row">
		<div class="col-md-8 col-lg-9">

			<article class="post">

				<div class="blog-content">

					<!--START ARTICLES Job Description -->
					
					<?php $__currentLoopData = $recruitment->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($section->title =='Job Description'): ?>
					<p class="lead"><?php echo $section->pivot->content; ?></p>
					<?php else: ?>

					<div class="job_reason_to_join_us" style="background-color: white; box-sizing: border-box; color: #333333; font-family: Roboto, sans-serif; font-size: 16px;">
						<h2 class="title" style="box-sizing: border-box; color: #353535; font-family: &quot;Roboto Condensed&quot;, sans-serif; font-size: 27px; font-weight: 400; line-height: 35.2px; margin: 20px 0px;">
							<?php echo $section->title; ?>

						</h2>
							<?php echo $section->pivot->content; ?>

					</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!--END ARTICLES -->

			</div>

		</article>


		<div class="widget widget_tag_cloud">
			<div class="widget-body">
				<?php $__currentLoopData = $recruitment->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<a href="#"><?php echo $tag->name; ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>

	</div>



	<div class="col-md-4 col-lg-3">

		<div class="widget widget_tag_cloud">
			<h6 class="widget-title">Tags</h6>
			<div class="widget-body">
				<a href="#">blog</a>
				<a href="#">new</a>
				<a href="#">google</a>
				<a href="#">position</a>
				<a href="#">facebook</a>
				<a href="#">hire</a>
				<a href="#">chance</a>
				<a href="#">resume</a>
				<a href="#">tip</a>
			</div>
		</div>

	</div>
</div>



</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.recruitment-detail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>