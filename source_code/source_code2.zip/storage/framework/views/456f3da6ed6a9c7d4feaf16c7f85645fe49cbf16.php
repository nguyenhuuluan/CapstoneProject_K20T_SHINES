<?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr id="<?php echo e($cv->id); ?>">
		<td><?php echo e($cv->name); ?></td>
		<td><?php echo e($cv->created_at); ?></td>
		<td>
			<a href="<?php echo e(route('student.cv.destroy', $cv->id)); ?>" data-id="<?php echo e($cv->id); ?>" id="delete"><abbr title="Xóa"><i class="fa fa-trash" aria-hidden="true"></i></abbr></a>
		</td>
	</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>