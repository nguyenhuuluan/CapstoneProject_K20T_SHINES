<?php $__env->startSection('page-header'); ?>
<header class="page-header bg-img" style="background-image: url(<?php echo e(asset('assets/img/bg-banner1.jpg')); ?> );">
  <div class="container page-name" style="padding-bottom: 100px">
    <form class="header-job-search" >
      <div class="input-keyword">
        <input type="text" class="form-control" placeholder="Tìm công việc hoặc công ty yêu thích">
      </div>

      <div class="input-location">
        <input type="text" class="form-control" placeholder="Thành phố bạn muốn làm việc">
      </div>

      <div class="btn-search">
        <button class="btn btn-primary" type="submit">Tìm</button>
      </div>
    </form>
  </div>
</header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main>
  <section class="no-padding-top bg-alt">
    <div class="container">
      <div class="row">

        <div class="searchcontent col-xs-12">
          <br>
          <h5>Chúng tôi đã tìm thấy <strong><?php echo $total; ?></strong> việc làm cho <strong style="color: red"><?php echo strtoupper($_GET['searchtext']); ?></strong> </h5>
        </div>
        
        <div class="recruitments endless-pagination" data-next-page="<?php echo e($recruitments->nextPageUrl()); ?>">

          <?php $__currentLoopData = $recruitments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <!-- Job item -->
          <div class="col-xs-12">
            <a class="item-block" href="<?php echo route('detailrecruitment', $recruitment->slug); ?>">
              <header>
                <img src=<?php echo asset(App\Recruitment::findOrFail($recruitment->id)->company->logo); ?> alt="">
                <div class="hgroup">
                  <h4><?php echo $recruitment->title; ?></h4>
                
                <?php $__currentLoopData = App\Recruitment::findOrFail($recruitment->id)->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->name =='FULL-TIME'): ?>
                <span class="label label-success"><?php echo $category->name; ?></span>
                <?php else: ?>
                <span class="label label-danger"><?php echo $category->name; ?></span>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <time><?php echo Carbon\Carbon::parse($recruitment->created_at)->diffForHumans(); ?></time>
            </header>

            <div class="item-body">
              <p><?php echo substr($recruitment->content, 0, 150) .'...'; ?></p>
            </div>

            <footer>
              <ul class="details cols-3">
                <li>
                  <i class="fa fa-map-marker"></i>
                  <span><?php echo $recruitment->district .', '. $recruitment->city; ?></span>
                </li>
                <li>
                  <i class="fa fa-money"></i>
                  <span class="salary"><?php echo $recruitment->salary; ?></span>
                </li>
                <li>
                  <i class="fa fa-tag"></i>
                  <?php $__currentLoopData = App\Recruitment::findOrFail($recruitment->id)->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="btn btn-info btn-xs"><?php echo $tag->name; ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
              </ul>
            </footer>
          </a>
        </div>
        <!-- END Job item -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      <div class="loading" style="text-align: center;">

        <img src="<?php echo e(asset('assets/img/bx_loader.gif')); ?>" style="width: 85px; height: 85px">

      </div>
    </div>

  </div>
</section>
</main>
<!-- END Main container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  $(document).ready(function(){

    $('.loading').hide();
    $(window).scroll(fetchPost);


    function fetchPost()
    {
      var page = $('.endless-pagination').data('next-page');
      // console.log(page.split('page=')[1]);
      // var tmp = window.location.href;
      if (page!==null && page.split('page=')[1]!=null)
      {
        $('.loading').show();
        clearTimeout($.data(this, 'scrollCheck'));
        $.data(this,'scrollCheck', setTimeout(function(){

          var scroll_position_for_recruitments_load = $(window).height() + $(window).scrollTop() +50;

          if(scroll_position_for_recruitments_load>=$(document).height())
          {
          	var url = window.location.href+'&page='+page.split('page=')[1];

           $.get(url, function(data){
              $('.recruitments').append(data.recruitments);
              $('.endless-pagination').data('next-page', data.next_page);
            })
            $('.loading').hide();
          }

        },450))
      }else
      {
            $('.loading').hide();
      }
    }

  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout',['title' => 'Tìm kiếm tin tuyển dụng', 'isDisplaySearchHeader' => true], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>