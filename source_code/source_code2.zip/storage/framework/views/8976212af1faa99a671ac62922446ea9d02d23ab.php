<?php $__env->startSection('meta-data'); ?>
<meta property="og:title"         content="<?php echo e($recruitment->title); ?>" />
<meta property="og:type"          content="website" />
<meta property="og:image"         content="<?php echo e(asset($recruitment->company->logo)); ?>" />
<meta property="og:url"           content="<?php echo e($currentURL); ?>" />


<meta property="og:description"   content="<?php $__currentLoopData = $recruitment->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($section->title =='Job Description'): ?>
<?php else: ?>
<?php echo trim(strip_tags($section->pivot->content)); ?>

<?php break; ?>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>


<header class="page-header bg-img size-lg" style="background-image: url(<?php echo e(asset('assets/img/bg-banner2.jpg')); ?> )">
	<div class="container">
		<div class="header-detail">
			<img class="logo" height="60" src=<?php echo asset($recruitment->company->logo); ?> alt="">
			<div class="hgroup">
				<h1><?php echo $recruitment->title; ?></h1>
			</div>
			<time datetime=""><?php echo $recruitment->created_at->diffForhumans(); ?></time>
			<ul class="details cols-3"  style="text-align: center">
				<li>
					<h3><a href="#"><?php echo $recruitment->company->name; ?></a></h3>
				</li>
				<li>
					<i class="fa fa-money"></i>
					<span class="salary"><?php echo $recruitment->salary; ?></span>
				</li>
				<li>
					<?php $__currentLoopData = $recruitment->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($category->name == 'FULL-TIME' ): ?>
					<span class="label label-success"><?php echo $category->name; ?></span>
					<?php else: ?>
					<span class="label label-danger"><?php echo $category->name; ?></span>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</li>
			</ul>

			<div class="button-group">
				<ul class="social-icons">
					<li class="title">Chia sẻ</li>					

					



				</ul>

				<div class="fb-share-button" data-href="<?php echo e($currentURL); ?>" data-layout="button_count" data-size="large" data-mobile-iframe="true"><a target="_blank" href=<?php echo e($currentURL.'&src=sdkpreparse'); ?> class="fb-xfbml-parse-ignore">Share</a>
				</div>

				



				<div class="action-buttons">
					<a class="btn btn-success-detail" href="job-apply.html">Ứng tuyển ngay</a>
				</div>

			</div>

		</div>
	</div>
</header>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<main class="container blog-page">

	<div class="row">
		<div class="col-md-8 col-lg-9">

			<article class="post">

				<div class="blog-content">

					<!--START ARTICLES Job Description -->
					
					<?php $__currentLoopData = $recruitment->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($section->title =='Job Description'): ?>
					<p class="lead"><?php echo $section->pivot->content; ?></p>
					<?php else: ?>

					<div class="job_reason_to_join_us" style="background-color: white; box-sizing: border-box; color: #333333; font-family: Roboto, sans-serif; font-size: 16px;">
						<h2 class="title" style="box-sizing: border-box; color: #353535; font-family: &quot;Roboto Condensed&quot;, sans-serif; font-size: 27px; font-weight: 400; line-height: 35.2px; margin: 20px 0px;">
							<?php echo $section->title; ?>

						</h2>
						<?php echo $section->pivot->content; ?>

					</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!--END ARTICLES -->

				</div>

			</article>


			<div class="widget widget_tag_cloud">
				<div class="widget-body">
					<?php $__currentLoopData = $recruitment->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<a href="#"><?php echo $tag->name; ?></a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

		</div>



		<div class="col-md-4 col-lg-3">

			<div class="widget widget_tag_cloud">
				<h6 class="widget-title">Tags</h6>
				<div class="widget-body">
					<a href="#">blog</a>
					<a href="#">new</a>
					<a href="#">google</a>
					<a href="#">position</a>
					<a href="#">facebook</a>
					<a href="#">hire</a>
					<a href="#">chance</a>
					<a href="#">resume</a>
					<a href="#">tip</a>
				</div>
			</div>

		</div>
	</div>



</main>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<script type="text/javascript">



	increaseView();

	function increaseView() {		
		var urlIncreaseView = "<?php echo e(route('recruitment.increaseview', ['recruitmentID'=>$recruitment->id])); ?>";
		$.ajax({
			url: urlIncreaseView,
			type: 'GET',
			success: function (response) {
			},
			error: function () {
				alert('error');
			}
		});

	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-layout', ['title' => $recruitment->title,'isDisplaySearchHeader' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>