 
 <?php echo Form::open(['method'=>'GET', 'action'=>'RecruitmentController@search', 'class'=>'header-job-search' ]); ?>

 <div class="input-keyword">
  <?php echo Form::text('searchtext', null, ['class'=>'form-control tagsinput-typeahead', 'placeholder'=>'Tìm công việc hoặc công ty yêu thích', 'data-role'=>'tagsinput']); ?>

</div>

<div class="input-location">
  <?php echo Form::text('city', null, ['class'=>'form-control', 'placeholder'=>'Thành phố bạn muốn làm việc']); ?>

</div>

<div class="btn-search">
  <?php echo Form::submit('Tìm', ['class'=>'btn btn-primary']); ?>

</div>

<?php echo Form::close(); ?>


