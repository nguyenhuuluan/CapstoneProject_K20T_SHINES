<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="description" content="Post a job position or create your online resume by TheJobs!">
   <meta name="keywords" content="">
   <title>Jobee</title>
   <!-- Styles -->
   <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">   
   <link href="<?php echo e(asset('assets/css/thejobs.css')); ?>" rel="stylesheet">
   <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
  
    <?php echo $__env->yieldContent('styles'); ?>

   <!-- Fonts -->
   <link href='http://fonts.googleapis.com/css?family=Oswald:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>
   <!-- Favicons -->
   <link rel="icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?> ">
</head>
<body class="nav-on-header smart-nav">
   <!-- Navigation bar -->
   <?php echo $__env->make('layouts.header-representative', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <!-- END Navigation bar -->
   <!-- Page header -->
   <header class="page-header">
      <div class="container page-name">
         <h1 class="text-center">Danh sách tin tuyển dụng của bạn</h1>
      </div>
   </header>
   <!-- END Page header -->
   <!-- Main container -->
    <?php echo $__env->yieldContent('body'); ?>
<!-- END Main container -->
<!-- Site footer -->
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END Site footer -->
<!-- Back to top button -->
<a id="scroll-up" href="#"><i class="ti-angle-up"></i></a>
<!-- END Back to top button -->
<!-- Scripts -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/thejobs.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>