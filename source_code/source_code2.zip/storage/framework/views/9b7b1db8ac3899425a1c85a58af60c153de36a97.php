<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<main>
  <center><h5>"The most important job is recruiting." - Steve Jobs</h5></center>
  <section>
   <div class="container">
    <div class="row">
     <h6>Trang báo cáo công ty</h6>
     <div class="table-responsive">
      <table class="table table-striped table-bordered-company">
       <thead>
        <tr>
         <th>Tổng số lượt xem</th>
         <th>Lượt xem trong 30 ngày</th>
         <th>Lượt xem trong 7 ngày</th>
       </tr>
     </thead>
     <tbody>
      <tr>
       <td>4500 (0.5 / ngày)</td>
       <td>300 (1.2 / ngày)</td>
       <td>50 (0.7 / ngày)</td>
     </tr>
   </tbody>
 </table>
</div>
</div>

</div>
</section>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.representative', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>