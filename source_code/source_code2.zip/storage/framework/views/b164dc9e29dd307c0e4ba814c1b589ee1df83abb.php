<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Post a job position or create your online resume by TheJobs!">
  <meta name="keywords" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e($title); ?></title>

  <!-- Styles -->
  <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/thejobs.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/alpha.css')); ?>" rel="stylesheet">
  
  <?php echo $__env->yieldContent("stylesheet"); ?>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


  <!-- Fonts -->
  <link href='http://fonts.googleapis.com/css?family=Oswald:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>

  <!-- Favicons -->
  <link rel="apple-touch-icon" href="<?php echo e(asset('/apple-touch-icon.png')); ?>">
  <link rel="icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?> ">
</head>

<body class="nav-on-header smart-nav">

 <!-- Navigation bar -->
 <?php echo $__env->make('layouts2.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!-- END Navigation bar -->


 <!-- Site header -->
  
 <!-- END Site header -->

<?php if($isDisplaySearchHeader): ?>
 <?php echo $__env->make('layouts2.search-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>

<header class="page-header temp-header"></header>
<?php endif; ?>

<?php echo $__env->yieldContent('sub-header'); ?>
 <!-- Main container -->

 <main>

  <!-- Recent jobs -->
  <?php echo $__env->yieldContent('content'); ?>
  <!-- <section></section> -->
  <!-- END Recent jobs -->
 
  <!-- END TESTIMONIAL -->
</main>
<!-- END Main container -->


<!-- Site footer -->
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Facts -->

<!-- Back to top button -->
<a id="scroll-up" href="#"><i class="ti-angle-up"></i></a>
<!-- END Back to top button -->

<!-- Scripts -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/thejobs.js')); ?> "></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?> "></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/alpha.js')); ?> "></script>



<script type="text/javascript">
  $(document).ready(function(){
    $('#testimonials').alpha({
      layout: 'alt',
      delay : 5300
    });
  })
</script>

<?php echo $__env->yieldContent("scripts"); ?>

</body>
</html>
