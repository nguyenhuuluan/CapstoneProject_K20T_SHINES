<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Post a job position or create your online resume by TheJobs!">
  <meta name="keywords" content="">

  <title>Jobee</title>

  <!-- Styles -->
  <link href="assets/css/app.min.css" rel="stylesheet">
  <link href="assets/css/thejobs.css" rel="stylesheet">
  <link href="assets/css/custom.css" rel="stylesheet">

  <!-- Fonts -->
  <link href='http://fonts.googleapis.com/css?family=Oswald:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>

  <!-- Favicons -->
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="icon" href="assets/img/favicon.ico">
</head>

<body class="nav-on-header smart-nav">

  <!-- Navigation bar -->
  <nav class="navbar">
    <div class="container">

      <!-- Logo -->
      <div class="pull-left">
        <a class="navbar-toggle" href="#" data-toggle="offcanvas"><i class="ti-menu"></i></a>

        <div class="logo-wrapper">
          <a class="logo" href="index.html"><img src="assets/img/logo.png" alt="logo"></a>
          <a class="logo-alt" href="index.html"><img src="assets/img/logo-alt.png" alt="logo-alt"></a>
        </div>

      </div>
      <!-- END Logo -->

      <!-- User account -->
      <div class="pull-right user-login">
        <a class="btn btn-sm btn-primary" href="user-login.html">Đăng kí</a> | <a href="user-register.html">Đăng nhập</a>
      </div>
      <!-- END User account -->

      <!-- Navigation menu -->
      <ul class="nav-menu">
        <li>
          <a class="active" href="index.html">Trang chủ</a>
        </li>
        <li>
          <a href="company-list.html">Công ty</a>
        </li>
        <li>
          <a href="job-list-1.html">Việc làm</a>
        </li>
        <li>
          <a href="#">Blog</a>
        </li>
        <li>
          <a href="#">Giới thiệu</a>
        </li>
      </ul>
      <!-- END Navigation menu -->

    </div>
  </nav>
  <!-- END Navigation bar -->


  <!-- Page header -->
  <header class="page-header bg-img size-lg" style="background-image: url(assets/img/bg-banner2.jpg)">
    <div class="container">
      <div class="header-detail">
        <img class="logo" src="assets/img/logo-google.jpg" alt="">
        <div class="hgroup">
          <h1>Senior front-end developer</h1>
        </div>
        <time datetime="2016-03-03 20:00">2 days ago</time>
        <ul class="details cols-3">
          <li>
              <h3><a href="#">Google</a></h3>
          </li>
          <li>
            <i class="fa fa-money"></i>
            <span class="salary">$90,000 - $110,000 / year</span>
          </li>
          <li>
            <i class="fa fa-cube"></i>
             <span class="positionwork">Full Time</span>
          </li>
        </ul>
       
         <div class="button-group">
            <ul class="social-icons">
              <li class="title">Share on</li>
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>

            <div class="action-buttons">
              <a class="btn btn-success-detail" href="job-apply.html">Apply now</a>
            </div>
          </div>


      </div>
    </div>
  </header>
  <!-- END Page header -->


  <!-- Main container -->
  <main class="container blog-page">

    <div class="row">
      <div class="col-md-8 col-lg-9">
        
        <article class="post">

          <div class="blog-content">

            <!--START ARTICLES -->
             <p class="lead">You will help Google build next-generation web applications like Gmail, Google Docs, Google Analytics, and the Google eBookstore and eBook readers. As a Front End Engineer at Google, you will specialize in building responsive and elegant web UIs with AJAX and similar technologies. You may design or work on frameworks for building scalable frontend applications. We are looking for engineers who are passionate about and have experience building leading-edge user experience, including dynamic consumer experiences.</p>

            <div class="job_reason_to_join_us" style="background-color: white; box-sizing: border-box; color: #333333; font-family: Roboto, sans-serif; font-size: 16px;">
              <h2 class="title" style="box-sizing: border-box; color: #353535; font-family: &quot;Roboto Condensed&quot;, sans-serif; font-size: 27px; font-weight: 400; line-height: 35.2px; margin: 20px 0px;">
              Top 3 Reasons To Join Us</h2>
              <div class="top-3-reasons" style="box-sizing: border-box; line-height: 1.7em;">
                <ul style="box-sizing: border-box; margin: 1em 0px; padding: 0px 0px 0px 40px;">
                  <li style="box-sizing: border-box;">International working environment</li>
                  <li style="box-sizing: border-box;">Competitive salary and benefit</li>
                  <li style="box-sizing: border-box;">Chance to work on-site in Singapore</li>
                </ul>
              </div>
              <h2>
              The Job</h2>
              <div class="description" style="box-sizing: border-box; color: #3a3a3a; line-height: 1.7em; width: 507.188px;">
                <ul style="box-sizing: border-box; margin: 1em 0px; padding: 0px 0px 0px 40px;">
                  <li style="box-sizing: border-box;">Handle server side design &amp; development of Garena products;</li>
                  <li style="box-sizing: border-box;">Be familiar with agile development, write high-quality, clean, simple, and maintainable code, build common libraries</li>
                  <li style="box-sizing: border-box;">Analyse requirements, design and develop functionality, according to product demands;</li>
                  <li style="box-sizing: border-box;">Acquire an in-depth understanding of products, constantly optimize the products, diagnose and fix problems, improve stability and user experience;</li>
                  <li style="box-sizing: border-box;">Design and implement various supporting tools as required;</li>
                  <li style="box-sizing: border-box;">Collaborate with other software engineers, product managers, user experience designers, and operation engineers to build new products.</li>
                </ul>
                <div style="box-sizing: border-box; margin-bottom: 1em; margin-top: 1em;">
                </div>
              </div>
            </div>
            <div class="skills_experience" style="background-color: white; box-sizing: border-box; color: #333333; font-family: Roboto, sans-serif; font-size: 16px; padding: 20px 0px 10px;">
              <h2 class="title" style="box-sizing: border-box; color: #353535; font-family: &quot;Roboto Condensed&quot;, sans-serif; font-size: 27px; font-weight: 400; line-height: 35.2px; margin: 0px;">
              Your Skills and Experience</h2>
              <div class="experience" style="box-sizing: border-box; color: #3a3a3a; line-height: 1.7em; width: 507.188px;">
                <div style="box-sizing: border-box; margin-bottom: 1em; margin-top: 1em;">
                </div>
                <ul style="box-sizing: border-box; margin: 1em 0px; padding: 0px 0px 0px 40px;">
                  <li style="box-sizing: border-box;">Bachelor's degree or higher in Computer Science or related fields&nbsp;<em style="box-sizing: border-box;">(Entry level/ Experienced);</em></li>
                  <li style="box-sizing: border-box;">Excellent working attitude, problem solving, critical thinking and communication skills;</li>
                  <li style="box-sizing: border-box;">Passionate about programming, innovation, and solving challenging problems;</li>
                  <li style="box-sizing: border-box;">Comprehensive knowledge in all areas of computer science (data structures and algorithms, operating systems, networks, security, databases, etc);</li>
                  <li style="box-sizing: border-box;">Familiar with C++/PHP/Python/Java, hands-on experience is preferred;</li>
                  <li style="box-sizing: border-box;">Familiar with common network protocols (TCP, UDP, HTTP), and network programming;</li>
                  <li style="box-sizing: border-box;">Familiar with Windows/Linux development environments, and multi-threaded programming;</li>
                  <li style="box-sizing: border-box;">Familiar with web technologies is preferred;</li>
                  <li style="box-sizing: border-box;">Experience in design and development of large-scale distributed systems is preferred</li>
                </ul>
                <div style="box-sizing: border-box; margin-bottom: 1em; margin-top: 1em;">
                </div>
              </div>
            </div>
            <h2 class="title" style="box-sizing: border-box; color: #353535; font-family: &quot;Roboto Condensed&quot;, sans-serif; font-size: 27px; font-weight: 400; line-height: 35.2px; margin: 0px;">
            Why You'll Love Working Here</h2>
            <div class="culture_description" style="box-sizing: border-box; color: #3a3a3a; line-height: 1.7em; width: 507.188px;">
              <div style="box-sizing: border-box; margin-bottom: 1em; margin-top: 1em;">
              </div>
              <ul style="box-sizing: border-box; margin: 1em 0px; padding: 0px 0px 0px 40px;">
                <li style="box-sizing: border-box;">Very attractive salary (2.000usd+)</li>
                <li style="box-sizing: border-box;">13th month salary is guaranteed</li>
                <li style="box-sizing: border-box;">Yearly allowance based-on performance.</li>
                <li style="box-sizing: border-box;">Extra health insurance plan (include accident): Health insurance package &amp; Private health insurance</li>
                <li style="box-sizing: border-box;">Lunch &amp; daily foods, compulsory insurance paid on 100% actual salary.</li>
                <li style="box-sizing: border-box;">Annual health check, company trip</li>
                <li style="box-sizing: border-box;">Onsite to Singapore office</li>
              </ul>
            </div>
            <!--END ARTICLES -->

          </div>

        </article>

        
         <div class="widget widget_tag_cloud">
          <div class="widget-body">
            <a href="#">blog</a>
            <a href="#">new</a>
            <a href="#">google</a>
            <a href="#">position</a>
            <a href="#">facebook</a>
            <a href="#">hire</a>
            <a href="#">chance</a>
            <a href="#">resume</a>
            <a href="#">tip</a>
          </div>
        </div>

      </div>



      <div class="col-md-4 col-lg-3">

        <div class="widget widget_tag_cloud">
          <h6 class="widget-title">Tags</h6>
          <div class="widget-body">
            <a href="#">blog</a>
            <a href="#">new</a>
            <a href="#">google</a>
            <a href="#">position</a>
            <a href="#">facebook</a>
            <a href="#">hire</a>
            <a href="#">chance</a>
            <a href="#">resume</a>
            <a href="#">tip</a>
          </div>
        </div>

      </div>
    </div>



  </main>
  <!-- END Main container -->


  <!-- Site footer -->
  <footer class="site-footer">

    <!-- Top section -->
    <div class="container">
      <div class="row">

        <div class="col-xs-6 col-sm-6 col-md-3">
          <h6>Trendeing jobs</h6>
          <ul class="footer-links">
            <li><a href="job-list.html">Front-end developer</a></li>
            <li><a href="job-list.html">Android developer</a></li>
            <li><a href="job-list.html">iOS developer</a></li>
            <li><a href="job-list.html">Full stack developer</a></li>
            <li><a href="job-list.html">Project administrator</a></li>
          </ul>
        </div>

        <div class="col-xs-6 col-sm-6 col-md-3">
          <h6>Company</h6>
          <ul class="footer-links">
            <li><a href="page-about.html">About us</a></li>
            <li><a href="page-typography.html">How it works</a></li>
            <li><a href="page-faq.html">Help center</a></li>
            <li><a href="page-typography.html">Privacy policy</a></li>
            <li><a href="page-contact.html">Contact us</a></li>
          </ul>
        </div>

        <div class="col-xs-6 col-sm-6 col-md-3">
          <h6>Company</h6>
          <ul class="footer-links">
            <li><a href="page-about.html">About us</a></li>
            <li><a href="page-typography.html">How it works</a></li>
            <li><a href="page-faq.html">Help center</a></li>
            <li><a href="page-typography.html">Privacy policy</a></li>
            <li><a href="page-contact.html">Contact us</a></li>
          </ul>
        </div>

        <div class="col-xs-6 col-sm-6 col-md-3">
          <h6>Trending jobs</h6>
          <ul class="footer-links">
            <li><a href="job-list.html">Front-end developer</a></li>
            <li><a href="job-list.html">Android developer</a></li>
            <li><a href="job-list.html">iOS developer</a></li>
            <li><a href="job-list.html">Full stack developer</a></li>
            <li><a href="job-list.html">Project administrator</a></li>
          </ul>
        </div>
      </div>

      <hr>
    </div>
    <!-- END Top section -->

    <!-- Bottom section -->
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-6 col-xs-12">
          <p class="copyright-text">Copyrights &copy; 2017 All Rights Reserved by <a href="#">Shines Team</a>.</p>
        </div>

        <div class="col-md-4 col-sm-6 col-xs-12">
          <ul class="social-icons">
            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
            <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
            <li><a class="instagram" href="#"><i class="fa fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- END Bottom section -->

  </footer>
  <!-- END Site footer -->


  <!-- Back to top button -->
  <a id="scroll-up" href="#"><i class="ti-angle-up"></i></a>
  <!-- END Back to top button -->

  <!-- Scripts -->
  <script src="assets/js/app.min.js"></script>
  <script src="assets/js/thejobs.js"></script>
  <script src="assets/js/custom.js"></script>

</body>
</html>
