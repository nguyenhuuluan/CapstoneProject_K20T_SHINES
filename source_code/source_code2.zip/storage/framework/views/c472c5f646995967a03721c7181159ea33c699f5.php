<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Post a job position or create your online resume by TheJobs!">
  <meta name="keywords" content="">

  <title>Jobee - Recruiment Preview</title>

  <!-- Styles -->
  <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/thejobs.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">

  <!-- Fonts -->
  <link href='http://fonts.googleapis.com/css?family=Oswald:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>

  <!-- Favicons -->
  <link rel="icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?> ">
</head>

<body class="nav-on-header smart-nav preview">

  <!-- Navigation bar -->
  <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- END Navigation bar -->

  
  <!-- Page header -->
  <header class="page-header bg-img size-lg" style="background-image: url(<?php echo e(asset('assets/img/bg-banner2.jpg')); ?> )">
    <div class="container">
      <div class="header-detail">
        <img class="logo" height="60" src="<?php echo $company->logo; ?>" alt="">
        <div class="hgroup">
          <h1><?php echo $data['title']; ?></h1>
        </div>
        <time datetime="">Just now</time>
        <ul class="details cols-3"  style="text-align: center">
          <li>
            <h3><a href="#"><?php echo $company->name; ?></a></h3>
          </li>
          <li>
            <i class="fa fa-money"></i>
            <span class="salary"><?php echo $data['salary']; ?></span>
          </li>
          <li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->name == 'FULL-TIME' ): ?>
            <span class="label label-success"><?php echo $category->name; ?></span>
            <?php else: ?>
            <span class="label label-danger"><?php echo $category->name; ?></span>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </li>
        </ul>
        
        <div class="button-group">
          <ul class="social-icons">
            <li class="title">Chia sẻ</li>
            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
          </ul>

          <div class="action-buttons">
            <a class="btn btn-success-detail" href="job-apply.html">Ứng tuyển ngay</a>
          </div>
        </div>


      </div>
    </div>
  </header>
  <!-- END Page header -->

  
  <!-- Main container -->
  <div id="watermark">
<p>Xem trước</p>
</div>
  <main class="container blog-page">

    <div class="row">
      <div class="col-md-8 col-lg-9">

        <article class="post">

          <div class="blog-content">

            <!--START ARTICLES Job Description -->

          <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($section->title =='Job Description'): ?>
          <p class="lead"><?php echo $section->content; ?></p>
          <?php else: ?>

          <div class="job_reason_to_join_us" style="background-color: white; box-sizing: border-box; color: #333333; font-family: Roboto, sans-serif; font-size: 16px;">
            <h2 class="title" style="box-sizing: border-box; color: #353535; font-family: &quot;Roboto Condensed&quot;, sans-serif; font-size: 27px; font-weight: 400; line-height: 35.2px; margin: 20px 0px;">
              <?php echo $section->title; ?>

            </h2>
              <?php echo $section->content; ?>

          </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!--END ARTICLES -->

        </div>

      </article>


      <div class="widget widget_tag_cloud">
        <div class="widget-body">
          <?php $__currentLoopData = $tags2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <a href="#"><?php echo $tag->name; ?></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

    </div>

    <div class="col-md-4 col-lg-3">
      <div class="widget widget_tag_cloud">
        <h6 class="widget-title">Tags</h6>
        <div class="widget-body">
          <a href="#">blog</a>
          <a href="#">new</a>
          <a href="#">google</a>
          <a href="#">position</a>
          <a href="#">facebook</a>
          <a href="#">hire</a>
          <a href="#">chance</a>
          <a href="#">resume</a>
          <a href="#">tip</a>
        </div>
      </div>
    </div>

  </div>
</main>
<!-- END Main container -->

<!-- Site footer -->
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- END Site footer -->
<!-- Scripts -->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/thejobs.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

</body>

</html>
