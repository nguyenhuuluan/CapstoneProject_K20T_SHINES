<?php $__env->startSection('body'); ?>



<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Danh sách công ty đang chờ xác nhận</h1>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="">

                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table width="100%" class="table table-striped table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>

                                            <th>Tên công ty</th>
                                            <th>Website</th>
                                            <th>Tên người đại diện</th>
                                            <th>Chức Vụ</th>             
                                            <th>Email người đại diện</th>
                                            <th>SĐT</th>

                                            <th>Ngày đăng ký</th>
                                            <th>Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $compsRegis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compRegis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($compRegis->status_id == 9): ?>
                                        <tr>
                                            <td><?php echo e($compRegis->company_name); ?></td>

                                            <td><a href="<?php echo e($compRegis->company_website); ?>"><?php echo e($compRegis->company_website); ?></a></td>
                                            <td><?php echo e($compRegis->representative_name); ?></td>
                                            <td><?php echo e($compRegis->representative_position); ?></td>
                                            <td><?php echo e($compRegis->representative_email); ?></td>
                                            <td><?php echo e($compRegis->representative_phone); ?></td>
                                            
                                            <td><?php echo e($compRegis->created_at); ?></td>
                                            <td>
                                               
                                                <button type="button" class="btn btn-default btn-success btn-approve" value = "<?php echo e($compRegis->id); ?>">

                                                    <span class="fa fa-check"></span> Xác nhận

                                                </button>
                                                
                                                
                                            </td>   </tr>
                                        <?php endif; ?>
                                                                               
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        </tbody>

                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>

                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>



    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">


        $('.btn-approve').click(function() {

           var currentelement = $(this);

           $.confirm({
            title: 'Thông báo!!',
            content: 'Bạn có muốn xác nhận công ty này?',
            buttons: {
                Có: {
                    keys: ['enter'],
                    btnClass: 'btn-green',
                    action: function(){
                       approveCompany(currentelement);
                   }
               },
               Không: {
                keys: ['esc'],
                btnClass: 'btn-red'              
            }

        }


    });

       });



        function approveCompany(element){
            $('.modal-ajax-loading').fadeIn("200");
            $.ajax({
                url: '../company/approve/' + element.val(),
                type: 'GET',
                dataType: 'json',
                success: function(response){
                    $('.modal-ajax-loading').fadeOut("200");
                    element.parent().parent().remove();
                    sendConfirmEmail(response.account_id, response.id, response.company_id);
                },
                error: function(){
                    $('.modal-ajax-loading').fadeOut("200");
                    alertError();
                }            
            });
        }

        function sendConfirmEmail(accID, repreID, compID){
            $.ajax({
                url: '../company/sendemailconfirm/' + accID + '/' + repreID + '/' +compID,
                type: 'GET',
                dataType: 'json',
                success: function(){
                    alert('OK');
                },
                error: function(){
                    
                }            
            });
        }


    </script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>