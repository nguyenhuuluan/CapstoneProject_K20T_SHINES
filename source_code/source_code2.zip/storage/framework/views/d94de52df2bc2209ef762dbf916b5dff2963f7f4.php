<?php $__env->startSection('stylesheet'); ?>

<link href="<?php echo e(asset('assets/css/jquery.bxslider.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-header'); ?>
<header class="page-header bg-img size-lg" style="background-image: url(assets/img/bg-banner1.jpg)">
  <div class="container">
    <div class="header-detail">
      <img class="logo" src="<?php echo e(asset($company->logo)); ?>" alt="">
      <div class="hgroup">
        <h1><?php echo e($company->name); ?></h1>
        <h3><?php echo e($company->field); ?></h3>
      </div>
      <hr>

      <ul class="details cols-3">
        <li>
          <i class="fa fa-map-marker"></i>
          <span><?php echo e($company->address->address); ?>, <?php echo e($company->address->district->name); ?>, <?php echo e($company->address->district->city->name); ?></span>
        </li>

        <li>

        </li>

        <li>
          <i class="fa fa-globe"></i>
          <a href="#"><?php echo e($company->website); ?></a>
        </li>


        <li>
          <i class="fa fa-phone"></i>
          <span><?php echo e($company->phone); ?></span>
        </li>

        <li>
          <i class="fa fa-envelope"></i>
          <a href="#"><?php echo e($company->email); ?></a>
        </li>
        <li>
          <i class="fa fa-calendar"></i>
          <span><?php echo e($company->working_day); ?></span>
        </li>
      </ul>

      <div class="button-group">
        <ul class="social-icons">

          <?php if($socials[0]->name === 'Facebook'): ?>
          <li><a class="facebook" href="<?php echo e($socials[0]->url); ?>"  target="_blank"><i class="fa fa-facebook"></i></a></li>
          <?php endif; ?>  

          <?php if($socials[1]->name === 'Facebook'): ?>
          <li><a class="facebook" href="<?php echo e($socials[0]->url); ?>"  target="_blank"><i class="fa fa-facebook"></i></a></li>
          <?php endif; ?>  

          <?php if($socials[0]->name === 'LinkedIn'): ?>
          <li><a class="linkedin" href="<?php echo e($socials[0]->url); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
          <?php endif; ?>

          <?php if($socials[1]->name === 'LinkedIn'): ?>
          <li><a class="linkedin" href="<?php echo e($socials[0]->url); ?>"  target="_blank"><i class="fa fa-linkedin"></i></a></li>
          <?php endif; ?>      

        </ul>

        <div class="action-buttons">
          <a class="btn btn-success" href="#">Liên hệ</a>
        </div>
      </div>

    </div>

  </div>
</header>
<br>
<br>

<div class="widget_tag_cloud" style="margin-left: 10%;">
  <div class="widget-body">
   <?php $__currentLoopData = $company->tags()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <a href="#"><?php echo e($tag->name); ?></a>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section>
  <div class="container">
    <br>
    <br>
    <header class="section-header">
      <h2>Giới thiệu</h2>
    </header>

    <p><?php echo e($company->introduce); ?></p>

  </div>
  <center>
    <div class="bxslider">

      <?php $__currentLoopData = $company->photos()->pluck('name')->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div><img src="<?php echo e(asset('images/companies/'.$photoname)); ?>"></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </center>
</section>
<!-- END Company detail -->


<!-- Open positions -->
<section id="open-positions" class="bg-alt">
  <div class="container">
    <header class="section-header">
      <h2>Vị trí đang tuyển</h2>
    </header>

    <div class="row">

      <?php if(count($recruitments) == 0): ?>
      <div class="col-xs-12">
        <center>Chưa có tin tuyển dụng nào</center>
      </div>
      <?php endif; ?>

      <?php $__currentLoopData = $recruitments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Job item -->

      <a class="item-block" href="<?php echo e(route('detailrecruitment', $recruitment->slug )); ?>">
        <header>
          <img src="<?php echo e(asset($recruitment->company->logo)); ?>" alt="">
          <div class="hgroup">
            <h4><?php echo e($recruitment->title); ?></h4>
            <h5><?php echo e($company->name); ?> 
              <?php $__currentLoopData = $recruitment->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($category->name =='FULL-TIME'): ?>
              <span class="label label-success"><?php echo e($category->name); ?></span>
              <?php else: ?>
              <span class="label label-danger"><?php echo e($category->name); ?></span>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h5>
          </div>
          <time datetime=""><?php echo $recruitment->created_at->diffForhumans(); ?></time>
        </header>

        <div class="item-body truncate">

          <?php $__currentLoopData = $recruitment->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($section->title =='Job Description'): ?>
          <p class="lead"><?php echo $section->pivot->content; ?></p>
          <?php else: ?>
          <span><?php echo $section->pivot->content; ?></span>
          <?php break; ?>

          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <footer>
          <ul class="details cols-3">
            <li>
              <i class="fa fa-map-marker"></i>
              <span class="location"><?php echo e($recruitment->company->address->district->city->name); ?></span>
            </li>

            <li>
              <i class="fa fa-money"></i>
              <span class="salary"><?php echo e($recruitment->salary); ?></span>
            </li>

            <li>
              <i class="fa fa-tag"></i>
              <span><?php echo e(implode(", ",$recruitment->tags()->pluck('name')->toArray())); ?> </span>


            </li>
          </ul>
        </footer>
      </a>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- END Job item -->


  </div>

</div>
</section>
<!-- END Open positions -->
<header class="section-header-map">
  <center><h2>Vị trí</h2></center>

  <center"><strong><span><?php echo e($company->address->address); ?>, <?php echo e($company->address->district->name); ?>, <?php echo e($company->address->district->city->name); ?></span></strong></center>
  <br>
</header>

<center><div id="contact-map" style="height: 400px; width: 90%;"></div></center> 
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.bxslider.js')); ?>"></script>


<script>
  $('.temp-header').hide();

  $('.bxslider').bxSlider({
    mode: 'fade',
    captions: true,
    slideWidth: 380
  });


</script>


<script>

  var lat = <?php echo e($company->address->latitude); ?>;
  var lng= <?php echo e($company->address->longtitude); ?>;


  function initMap() {
    var uluru = {lat: lat, lng: lng};
    var map = new google.maps.Map(document.getElementById('contact-map'), {
      zoom: 15,
      center: uluru
    });
    var marker = new google.maps.Marker({
      position: uluru,
      map: map
    });
  }
</script>

<script src="https://maps.googleapis.com/maps/api/js?callback=initMap&key=AIzaSyBTKdxpxRWTD9UnpMVrGfdnNCmFZLde8Rw" async defer></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts2.master-layout',['title' => 'Thông tin công ty', 'isDisplaySearchHeader' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>