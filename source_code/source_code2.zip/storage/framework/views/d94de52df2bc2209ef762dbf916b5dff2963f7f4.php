<?php $__env->startSection('sub-header'); ?>
<header class="page-header bg-img size-lg" style="background-image: url(assets/img/bg-banner1.jpg)">
    <div class="container">
      <div class="header-detail">
        <img class="logo" src="<?php echo e(asset($company->logo)); ?>" alt="">
        <div class="hgroup">
          <h1><?php echo e($company->name); ?></h1>
          <h3><?php echo e($company->field); ?></h3>
      </div>
      <hr>

      <ul class="details cols-3">
          <li>
            <i class="fa fa-map-marker"></i>
            <span><?php echo e($company->address->address); ?>, <?php echo e($company->address->district->name); ?>, <?php echo e($company->address->district->city->name); ?></span>
        </li>

        <li>

        </li>

        <li>
            <i class="fa fa-globe"></i>
            <a href="#"><?php echo e($company->website); ?></a>
        </li>


        <li>
            <i class="fa fa-phone"></i>
            <span><?php echo e($company->phone); ?></span>
        </li>

        <li>
            <i class="fa fa-envelope"></i>
            <a href="#"><?php echo e($company->email); ?></a>
        </li>
        <li>
            <i class="fa fa-calendar"></i>
            <span><?php echo e($company->working_day); ?></span>
        </li>
    </ul>

    <div class="button-group">
      <ul class="social-icons">

        <?php if($socials[0]->name === 'Facebook'): ?>
        <li><a class="facebook" href="<?php echo e($socials[0]->url); ?>"><i class="fa fa-facebook"></i></a></li>
        <?php endif; ?>  

        <?php if($socials[1]->name === 'Facebook'): ?>
        <li><a class="facebook" href="<?php echo e($socials[0]->url); ?>"><i class="fa fa-facebook"></i></a></li>
        <?php endif; ?>  

        <?php if($socials[0]->name === 'LinkedIn'): ?>
        <li><a class="facebook" href="<?php echo e($socials[0]->url); ?>"><i class="fa fa-linkedin"></i></a></li>
        <?php endif; ?>

        <?php if($socials[1]->name === 'LinkedIn'): ?>
        <li><a class="facebook" href="<?php echo e($socials[0]->url); ?>"><i class="fa fa-linkedin"></i></a></li>
        <?php endif; ?>      

    </ul>

    <div class="action-buttons">
        <a class="btn btn-success" href="#">Liên hệ</a>
    </div>
</div>

</div>

</div>
</header>
<br>
<br>

<div class="widget widget_tag_cloud" style="margin-left: 10%;">
    <div class="widget-body">


     <?php $__currentLoopData = $company->tags()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <a href="#"><?php echo e($tag->name); ?></a>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section>
  <div class="container">
    <br>
    <br>
    <header class="section-header">
      <h2>Giới thiệu</h2>
  </header>

  <p><?php echo e($company->introduce); ?></p>

</div>
</section>
<!-- END Company detail -->


<!-- Open positions -->
<section id="open-positions" class="bg-alt">
  <div class="container">
    <header class="section-header">
      <h2>Vị trí đang tuyển</h2>
  </header>

  <div class="row">

      <!-- Job item -->
      <div class="col-xs-12">
        <a class="item-block" href="job-detail.html">
          <header>
            <img src="assets/img/logo-google.jpg" alt="">
            <div class="hgroup">
              <h4>Senior front-end developer</h4>
              <h5>Google <span class="label label-danger">Full-time</span></h5>
          </div>
          <time datetime="2016-03-10 20:00">32 phút trước</time>
      </header>

      <div class="item-body">
        <p>Tham gia phát triển các dự án trên nền tảng C# của khách hàng, tham gia vào tất cả các giai đoạn của 1 dự án như: lập kế hoạch, phân tích, thiết kế, thực thi, kiểm thử, và triển khai cũng như bảo trì.</p>
    </div>

    <footer>
        <ul class="details cols-3">
          <li>
            <i class="fa fa-map-marker"></i>
            <span>Hồ Chí Minh</span>
        </li>

        <li>
            <i class="fa fa-money"></i>
            <span class="salary">$90,000 - $110,000 / năm</span>
        </li>

        <li>
            <i class="fa fa-tag"></i>
            <span>Master or Bachelor</span>
        </li>
    </ul>
</footer>
</a>
</div>
<!-- END Job item -->
<!-- Job item -->
<div class="col-xs-12">
    <a class="item-block" href="job-detail.html">
      <header>
        <img src="assets/img/logo-google.jpg" alt="">
        <div class="hgroup">
          <h4>Senior front-end developer</h4>
          <h5>Google <span class="label label-danger">Full-time</span></h5>
      </div>
      <time datetime="2016-03-10 20:00">34 phút trước</time>
  </header>

  <div class="item-body">
    <p>Tham gia phát triển các dự án trên nền tảng C# của khách hàng, tham gia vào tất cả các giai đoạn của 1 dự án như: lập kế hoạch, phân tích, thiết kế, thực thi, kiểm thử, và triển khai cũng như bảo trì.</p>
</div>

<footer>
    <ul class="details cols-3">
      <li>
        <i class="fa fa-map-marker"></i>
        <span>Hồ Chí Minh</span>
    </li>

    <li>
        <i class="fa fa-money"></i>
        <span class="salary">$90,000 - $110,000 / năm</span>
    </li>

    <li>
        <i class="fa fa-tag"></i>
        <span>HTML, CSS, JavaScript</span>
    </li>
</ul>
</footer>
</a>
</div>
<!-- END Job item -->
<!-- Job item -->
<div class="col-xs-12">
    <a class="item-block" href="job-detail.html">
      <header>
        <img src="assets/img/logo-google.jpg" alt="">
        <div class="hgroup">
          <h4>Senior front-end developer</h4>
          <h5>Google <span class="label label-success">Full-time</span></h5>
      </div>
      <time datetime="2016-03-10 20:00">32 phút trước</time>
  </header>

  <div class="item-body">
    <p>Tham gia phát triển các dự án trên nền tảng C# của khách hàng, tham gia vào tất cả các giai đoạn của 1 dự án như: lập kế hoạch, phân tích, thiết kế, thực thi, kiểm thử, và triển khai cũng như bảo trì.</p>
</div>

<footer>
    <ul class="details cols-3">
      <li>
        <i class="fa fa-map-marker"></i>
        <span>Hồ Chí Minh</span>
    </li>

    <li>
        <i class="fa fa-money"></i>
        <span class="salary">$90,000 - $110,000 / năm</span>
    </li>

    <li>
        <i class="fa fa-tag"></i>
        <span>HTML, CSS, JavaScript</span>
    </li>
</ul>
</footer>
</a>
</div>
<!-- END Job item -->
<!-- Job item -->
<div class="col-xs-12">
    <a class="item-block" href="job-detail.html">
      <header>
        <img src="assets/img/logo-google.jpg" alt="">
        <div class="hgroup">
          <h4>Senior front-end developer</h4>
          <h5>Google <span class="label label-success">Full-time</span></h5>
      </div>
      <time datetime="2016-03-10 20:00">34 phút trước</time>
  </header>

  <div class="item-body">
    <p>Tham gia phát triển các dự án trên nền tảng C# của khách hàng, tham gia vào tất cả các giai đoạn của 1 dự án như: lập kế hoạch, phân tích, thiết kế, thực thi, kiểm thử, và triển khai cũng như bảo trì.</p>
</div>

<footer>
    <ul class="details cols-3">
      <li>
        <i class="fa fa-map-marker"></i>
        <span>Hồ Chí Minh</span>
    </li>

    <li>
        <i class="fa fa-money"></i>
        <span class="salary">$90,000 - $110,000 / năm</span>
    </li>

    <li>
        <i class="fa fa-tag"></i>
        <span>HTML, CSS, JavaScript</span>
    </li>
</ul>
</footer>
</a>
</div>
<!-- END Job item -->
<!-- Job item -->
<div class="col-xs-12">
    <a class="item-block" href="job-detail.html">
      <header>
        <img src="assets/img/logo-google.jpg" alt="">
        <div class="hgroup">
          <h4>Senior front-end developer</h4>
          <h5>Google <span class="label label-success">Full-time</span></h5>
      </div>
      <time datetime="2016-03-10 20:00">34 phút trước</time>
  </header>

  <div class="item-body">
    <p>Tham gia phát triển các dự án trên nền tảng C# của khách hàng, tham gia vào tất cả các giai đoạn của 1 dự án như: lập kế hoạch, phân tích, thiết kế, thực thi, kiểm thử, và triển khai cũng như bảo trì.</p>
</div>

<footer>
    <ul class="details cols-3">
      <li>
        <i class="fa fa-map-marker"></i>
        <span>Hồ Chí Minh</span>
    </li>

    <li>
        <i class="fa fa-money"></i>
        <span class="salary">$90,000 - $110,000 / năm</span>
    </li>

    <li>
        <i class="fa fa-tag"></i>
        <span>HTML, CSS, JavaScript</span>
    </li>
</ul>
</footer>
</a>
</div>
<!-- END Job item -->


</div>

</div>
</section>
<!-- END Open positions -->
<header class="section-header-map">
  <center><h2>Vị trí</h2></center>
  <center><strong><span><?php echo e($company->address->address); ?>, <?php echo e($company->address->district->name); ?>, <?php echo e($company->address->district->city->name); ?></span></strong></center>
  <br>
</header>

<div id="contact-map" style="height: 400px"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('.temp-header').hide();

</script>


<script>

var lat = <?php echo e($company->address->latitude); ?>;
var lng= <?php echo e($company->address->longtitude); ?>;


  function initMap() {
    var uluru = {lat: lat, lng: lng};
    var map = new google.maps.Map(document.getElementById('contact-map'), {
        zoom: 15,
        center: uluru
    });
    var marker = new google.maps.Marker({
      position: uluru,
      map: map
  });
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?callback=initMap&key=AIzaSyBTKdxpxRWTD9UnpMVrGfdnNCmFZLde8Rw" async defer></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts2.master-layout',['title' => 'Thông tin công ty', 'isDisplaySearchHeader' => false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>