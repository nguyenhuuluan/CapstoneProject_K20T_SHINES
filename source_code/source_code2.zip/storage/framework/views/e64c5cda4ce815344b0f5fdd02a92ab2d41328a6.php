
<nav class="navbar">
  <div class="container">
    <!-- Logo -->
    <div class="pull-left">
      <a class="navbar-toggle" href="#" data-toggle="offcanvas"><i class="ti-menu"></i></a>
      <div class="logo-wrapper">

        <a class="logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="logo"></a>
        <a class="logo-alt" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/img/logo-alt.png')); ?>" alt="logo-alt"></a>

      </div>
    </div>
    <!-- END Logo -->

    <!-- SignUp/SignIn Candidate-->
    <div id="id02" class="modal fade" role="dialog">
      <form class="modal-content animate" method="POST" action="<?php echo e(route('login')); ?>">
       <?php echo e(csrf_field()); ?>

       <div class="login-block">
        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="">
        <br><br>
        <ul class="nav nav-tabs">
          <li class="active">
            <a data-toggle="tab" onclick="modalSignInOut('dangnhap')" href="#">Đăng nhập</a>
          </li>
          <li>
            <a data-toggle="tab" onclick="modalSignInOut('dangky')" href="#">Đăng ký</a>
          </li>
        </ul>

        <div id="dangnhap" class="modalinout">
          <div class="form-group" form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>> 
           <div class="input-group">
             <span class="input-group-addon"><i class="ti-email"></i></span>
             <input id="email" type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
           </div>
         </div>
         <hr class="hr-xs">
         <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
           <div class="input-group">
             <span class="input-group-addon"><i class="ti-unlock"></i></span>
             <input id="password" type="password" class="form-control" placeholder="Mật khẩu" name="password" required>
           </div>
         </div>

         <?php if($errors->has('email')): ?>
         <span class="help-block">
          <strong style="color: red"><?php echo e($errors->first('email')); ?></strong>
          <script src="<?php echo e(asset('assets/js/app.min.js')); ?> "></script>
          <script type="text/javascript" src="<?php echo e(asset('assets/js/alpha.js')); ?> "></script>
          <script type="text/javascript">
            $('#id02').modal('show');
          </script>
        </span>
        <?php endif; ?>

        <?php if(Session::has('comment_message')): ?>  
        <strong style="color: red"><?php echo e(session('comment_message')); ?></strong>
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?> "></script>
        <script type="text/javascript" src="<?php echo e(asset('assets/js/alpha.js')); ?> "></script>
        <script type="text/javascript">
          $('#id02').modal('show');
        </script>
        <?php endif; ?>

        <?php if($errors->has('password')): ?>
        <span class="help-block">
          <strong style="color: red"><?php echo e($errors->first('password')); ?></strong>
          <script src="<?php echo e(asset('assets/js/app.min.js')); ?> "></script>
          <script type="text/javascript" src="<?php echo e(asset('assets/js/alpha.js')); ?> "></script>
          <script type="text/javascript">
            $('#id02').modal('show');
          </script>
        </span>
        <?php endif; ?>

        <button name="registerCandidate" class="btn btn-primary btn-block" type="submit">Đăng Nhập</button>
        <div class="login-links">
          <center><a href="forget-password.html">Quên mật khẩu?</a></center>
        </div>
      </div>
    </form>
    <form method="POST" action="<?php echo e(route('student.register')); ?>">
     <?php echo e(csrf_field()); ?>


     <div id="dangky" class="modalinout" style="display:none">

      <?php if(Session::has('resigter-success')): ?>
      <br>
      <div class="alert alert-success">         
        <span><?php echo session('resigter-success'); ?></span>
      </div>
      <?php elseif(Session::has('email-invalid')): ?>
      <br>
      <div class="alert alert-danger">         
        <span><?php echo session('email-invalid'); ?></span>
      </div>
      <?php elseif(Session::has('email-exist')): ?>
      <br>
      <div class="alert alert-warning">         
        <span><?php echo session('email-exist'); ?></span>
      </div>
      <?php endif; ?>

      <div class="form-group">
        <div class="input-group">
          <span class="input-group-addon"><i class="ti-email"></i></span>
          <input name="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email: jobee@vanlanguni.vn">
        </div>
      </div>

      <button name="registerCandidate" class="btn btn-primary btn-block" type="submit">Đăng Ký</button>
    </form>
  </div>
</div>
</div>


<!-- End SignUp/SignIn Candidate -->

<!-- User account -->
<div class="pull-right user-login">
  <?php if(auth()->guard()->guest()): ?>
  <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#id02" href="#">Đăng nhập</a> | <a href="<?php echo e(route('company.partnership')); ?>">Nhà tuyển dụng</a>
  <?php else: ?>
  <?php if(Auth::user()->isStudent()): ?>
  <div class="pull-right">
   <div class="dropdown user-account">
    <a class="user-account-text"> <?php echo Auth::user()->student->name; ?></a>
    <a class="dropdown-toggle" href="#" data-toggle="dropdown">
      <img src=<?php echo e(asset(Auth::user()->student->photo)); ?> alt="avatar">
    </a>
    <ul class="dropdown-menu dropdown-menu-right">
      <li><a href="<?php echo e(route('student.profile.update')); ?>"><i class="fa fa-user" aria-hidden="true"></i>Tài khoản</a></li>
      <li><a href="<?php echo e(route('student.profile')); ?>"><i class="fa fa-file" aria-hidden="true"></i>Hồ sơ</a></li>
      <li><a href="#"><i class="fa fa-save" aria-hidden="true"></i> Việc làm đã lưu</a></li>
      <li><a href="#"><i class="fa fa-check-circle" aria-hidden="true"></i> Việc làm đã ứng tuyển</a></li> 
      <li>
        <a href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault();document.getElementById('logout-form').submit();">Đăng xuất</a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo e(csrf_field()); ?>

        </form>
      </li>
    </ul>
  </div>
</div>

<?php elseif(Auth::user()->isAdmin()): ?>
<a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#id02" href="#">Đăng nhập</a> | <a href="<?php echo e(route('company.partnership')); ?>">Nhà tuyển dụng</a>

<?php elseif(Auth::user()->isRepresentative()): ?>
<div class="pull-right">
 <div class="dropdown user-account">
  <a class="user-account-text"> <?php echo Auth::user()->representative->name; ?></a>
  <a class="dropdown-toggle" href="#" data-toggle="dropdown">
    <img src="<?php echo e(asset('assets/img/logo-envato.png')); ?> " alt="avatar">
  </a>
  <ul class="dropdown-menu dropdown-menu-right">
   <li><a href="#"><i class="fa fa-user" aria-hidden="true"></i> Tài khoản</a></li>
   <li><a href="<?php echo e(route('company.statistic')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> Bảng điều khiển</a></li>
   <li><a href="<?php echo e(route('company.update')); ?>"><i class="fa fa-building-o" aria-hidden="true"></i> Công ty của bạn</a></li>
   <li><a href="<?php echo e(route('recruitments.index')); ?>"><i class="fa fa-newspaper-o" aria-hidden="true"></i> Việc làm đã đăng</a></li>
   <li><a href="#"><i class="fa fa-users" aria-hidden="true"></i> Danh sách ứng tuyển</a></li>
   <li><a href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i>Đăng xuất</a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
     <?php echo e(csrf_field()); ?>

   </form>
 </li>
</ul>
</div>
</div>
<?php endif; ?>

<?php endif; ?>        
</div>
<!-- END User account -->

<!-- Navigation menu -->
<ul class="nav-menu">
  <li>
    <a class="active" href="<?php echo e(route('home')); ?>">Trang chủ</a>
  </li>
  <li>
    <a href="#">Công ty</a>
  </li>
  <li>
    <a href="#">Việc làm</a>
  </li>
  <li>
    <a href="#">Blog</a>
  </li>
  <li>
    <a href="#">Giới thiệu</a>
  </li>
</ul>
<!-- END Navigation menu -->
</div>
</nav>

<?php $__env->startSection('scripts'); ?>

<?php if(Session::has('resigter-success') || Session::has('email-invalid') || Session::has('email-exist')): ?>

<script type="text/javascript" charset="utf-8">
  $("#id02").modal("show");

  $('.nav-tabs li:first-child').removeClass('active');
  $('.nav-tabs li:last-child').addClass('active');
  modalSignInOut('dangky');

  // $('.nav-tabs li:last-child a').attr("aria-expanded", true);
  //$('.login-block').css( "display", "none");
  

</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<script>

  function modalSignInOut(nameinout) {
    var i;
    var x = document.getElementsByClassName("modalinout");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
    }
    document.getElementById(nameinout).style.display = "block";  
  }
</script>



