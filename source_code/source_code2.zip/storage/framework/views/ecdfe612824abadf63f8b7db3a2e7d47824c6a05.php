 <?php $__currentLoopData = $recruitments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recruitment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <!-- Job item -->
 <div class="col-xs-12">
  <a class="item-block" href="<?php echo route('detailrecruitment', $recruitment->slug); ?>">
    <header>
      <img src=<?php echo asset(App\Recruitment::findOrFail($recruitment->id)->company->logo); ?> alt="">
      <div class="hgroup">
        <h4><?php echo $recruitment->title; ?></h4>
                
                <?php $__currentLoopData = App\Recruitment::findOrFail($recruitment->id)->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->name =='FULL-TIME'): ?>
                <span class="label label-success"><?php echo $category->name; ?></span>
                <?php else: ?>
                <span class="label label-danger"><?php echo $category->name; ?></span>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <time><?php echo Carbon\Carbon::parse($recruitment->created_at)->diffForHumans(); ?></time>
              
            </header>

            <div class="item-body">
              <p><?php echo substr($recruitment->content, 0, 150) .'...'; ?></p>
            </div>

            <footer>
              <ul class="details cols-3">
                <li>
                  <i class="fa fa-map-marker"></i>
                  <span><?php echo $recruitment->district .', '. $recruitment->city; ?></span>
                </li>
                <li>
                  <i class="fa fa-money"></i>
                  <span class="salary"><?php echo $recruitment->salary; ?></span>
                </li>
                <li>
                  <i class="fa fa-tag"></i>
                  <?php $__currentLoopData = App\Recruitment::findOrFail($recruitment->id)->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <span class="btn btn-info btn-xs"><?php echo $tag->name; ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
              </ul>
            </footer>
          </a>
        </div>
        <!-- END Job item -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>